import { TOOLS } from '../data/itemsCatalog';
import { ToolKind, ToolSpec } from '../types/gameplay';

export interface ResourceNodeLike {
  id: string;
  requiredToolKind: ToolKind;
  minToolQualityRank: number; // 0 = à mains nues possible, 1 = brut+, 2 = fer+
  baseHits: number;
}

const QUALITY_RANK: Record<ToolSpec['quality'], number> = {
  crude: 1,
  iron: 2,
  tempered: 3,
};

export function resolveHarvestAttempt(
  node: ResourceNodeLike,
  equippedToolId: string | undefined,
  bareHandDamage = 0.25
): { allowed: boolean; progressDelta: number; reason?: string } {
  const tool = equippedToolId ? TOOLS[equippedToolId] : undefined;

  if (!tool) {
    if (node.minToolQualityRank > 0) {
      return {
        allowed: false,
        progressDelta: 0,
        reason: `Outil requis : ${node.requiredToolKind}.`,
      };
    }
    return {
      allowed: true,
      progressDelta: bareHandDamage / Math.max(1, node.baseHits),
    };
  }

  if (tool.kind !== node.requiredToolKind) {
    return {
      allowed: false,
      progressDelta: 0,
      reason: `Cet outil (${tool.kind}) n'est pas adapté (${node.requiredToolKind}).`,
    };
  }

  const rank = QUALITY_RANK[tool.quality];
  if (rank < node.minToolQualityRank) {
    return {
      allowed: false,
      progressDelta: 0,
      reason: 'Qualité d’outil insuffisante pour ce matériau.',
    };
  }

  const hitsNeeded = Math.max(1, node.baseHits / (tool.harvestPower * tool.speedMultiplier));
  return {
    allowed: true,
    progressDelta: 1 / hitsNeeded,
  };
}
