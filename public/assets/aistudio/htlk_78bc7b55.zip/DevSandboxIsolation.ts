import { ThornvaleSaveV2 } from '../types/gameplay';
import { readNormalSave, writeNormalSave } from './SaveMigrationSystem';

export class DevSandboxIsolation {
  private devModeActive = false;
  private snapshotBeforeDev: ThornvaleSaveV2 | null = null;
  private temporaryDevState: ThornvaleSaveV2 | null = null;

  public isDevModeActive(): boolean {
    return this.devModeActive;
  }

  public activateDevMode(): ThornvaleSaveV2 {
    if (this.devModeActive && this.temporaryDevState) {
      return structuredClone(this.temporaryDevState);
    }
    const normal = readNormalSave();
    this.snapshotBeforeDev = structuredClone(normal);
    this.temporaryDevState = structuredClone(normal);
    this.devModeActive = true;
    return structuredClone(this.temporaryDevState);
  }

  public deactivateDevModeAndRestore(): ThornvaleSaveV2 {
    const restored = this.snapshotBeforeDev
      ? structuredClone(this.snapshotBeforeDev)
      : readNormalSave();

    writeNormalSave(restored);
    this.devModeActive = false;
    this.snapshotBeforeDev = null;
    this.temporaryDevState = null;
    return restored;
  }

  public persistState(state: ThornvaleSaveV2): void {
    if (this.devModeActive) {
      this.temporaryDevState = structuredClone(state);
      return;
    }
    writeNormalSave(state);
  }
}
