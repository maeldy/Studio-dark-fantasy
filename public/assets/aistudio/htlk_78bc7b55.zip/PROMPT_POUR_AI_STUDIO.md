# Instructions d'intégration pour Google AI Studio (PROMPT 5 — THORNVALE)

Copie-colle le prompt ci-dessous directement dans **Google AI Studio** en joignant ce dossier / ces fichiers à ton projet **THORNVALE** :

---

## Prompt à envoyer à Google AI Studio

> « Applique la mise à jour **PROMPT 5** à partir de l'architecture modulaire fournie (`src/types/gameplay.ts`, `src/data/*`, `src/systems/*`, `src/visuals/LowPolyGearBuilder.ts`, `src/components/*`, `src/integration/ThornvaleGameplayController.ts`).
>
> **Règles d'intégration strictes :**
> 1. **Relie ces modules aux systèmes existants de THORNVALE** (inventaire, récolte de ressources, IA/créatures, terrain/collisions, sauvegarde locale et mode développeur) sans créer de systèmes parallèles ni casser ce qui existe déjà.
> 2. **Combat & équipement :** connecte `CombatSystem` et `EquipmentSystem` au joueur et aux créatures existantes (portée réelle, ligne de vue/occlusion, fenêtres d'attaque/parade/esquive, recul, mort et réapparition au point sûr/camp sans casser l'état du monde).
> 3. **Outils & récolte :** connecte `ToolHarvestBridge` aux nœuds de récolte existants (arbres, roches, minerais, plantes) pour que le type et la qualité d'outil conditionnent l'accès et la vitesse de récolte.
> 4. **Fabrication (crafting) :** connecte `CraftingSystem` et `CraftingStationModal` aux installations du monde (`none`, `workbench`, `forge`, `furnace`, `anvil`). Empêche toute fabrication multiple involontaire et garantis la consommation stricte des ingrédients avant ajout de l'objet fabriqué.
> 5. **Construction :** connecte `ConstructionSystem` et `ConstructionBar` au terrain et aux collisions (aperçu 3D vert/rouge, vérification pente/obstacles/chevauchements, consommation réelle des matériaux, collisions actives des structures posées).
> 6. **Persistance & migration :** utilise `SaveMigrationSystem` pour conserver compatibilité ascendante avec les sauvegardes existantes et sauvegarder/restaurer l'équipement, l'inventaire, les recettes débloquées, les constructions placées par zone et l'état du joueur au changement de zone ou rechargement.
> 7. **Isolation stricte du mode développeur :** branche `DevSandboxIsolation` et `DevGameplayPanel` sur le mode développeur existant. Lorsque le mode développeur est activé, capture un instantané de la sauvegarde normale ; toute action de test (spawn d'armes, armures, outils, ressources, constructions, soins/dégâts, test de combat) reste isolée en mémoire et ne doit JAMAIS corrompre ou écraser la sauvegarde normale. À la sortie du mode développeur, restaure exactement l'état normal initial.
> 8. **Ergonomie Android & PC :** affiche `GameplayHud` avec commandes tactiles confortables sur mobile et raccourcis clavier/souris cohérents sur ordinateur, dans l'esthétique sombre, sobre et low-poly PS1 de THORNVALE. »

---

## Contenu de l'archive

- `src/types/gameplay.ts` : Types TypeScript (armes, armures, outils, recettes, stats de combat, constructions, format de sauvegarde v2).
- `src/data/itemsCatalog.ts` : Catalogue des armes, armures, boucliers et outils.
- `src/data/craftingRecipes.ts` : Recettes liées aux stations (`none`, `workbench`, `forge`, `furnace`, `anvil`) et déblocages.
- `src/data/buildablesCatalog.ts` : Catalogue des structures constructibles (feu de camp, coffre, établi, barrière, palissade, structure bois, abri).
- `src/systems/CombatSystem.ts` : Boucle de combat complète (phases windup/active/recovery, combos, blocage/parade, esquive, portée, ligne de vue, mort/respawn).
- `src/systems/EquipmentSystem.ts` : Gestion des emplacements d'équipement et calcul des bonus d'attaque/défense/endurance.
- `src/systems/ToolHarvestBridge.ts` : Passerelle entre outils équipés et nœuds de récolte.
- `src/systems/CraftingSystem.ts` : Validation stricte des ressources et fabrication atomique par station.
- `src/systems/ConstructionSystem.ts` : Aperçu 3D, validation terrain/pente/collisions, placement et persistance par zone.
- `src/systems/SaveMigrationSystem.ts` : Migration ascendante de sauvegarde et lecture/écriture sécurisée.
- `src/systems/DevSandboxIsolation.ts` : Isolation complète du mode développeur vis-à-vis de la sauvegarde normale.
- `src/visuals/LowPolyGearBuilder.ts` : Génération procédurale low-poly PS1 des armes, boucliers et constructions.
- `src/components/GameplayHud.tsx` : HUD combat, endurance, équipement et commandes tactiles Android/PC.
- `src/components/CraftingStationModal.tsx` : Fenêtre de fabrication filtrée par installation.
- `src/components/ConstructionBar.tsx` : Barre de sélection et validation de placement de structures.
- `src/components/DevGameplayPanel.tsx` : Panneau développeur pour tester armes, armures, outils, ressources, constructions et combat.
- `src/integration/ThornvaleGameplayController.ts` : Contrôleur central prêt à relier à la scène Three.js et à l'état React existant.
