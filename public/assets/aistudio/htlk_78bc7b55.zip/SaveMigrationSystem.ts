import { ThornvaleSaveV2 } from '../types/gameplay';

const STORAGE_KEY = 'thornvale_save_state';

export function createDefaultSave(
  zoneId = 'thornvale_forest',
  spawnPoint: [number, number, number] = [0, 0, 0]
): ThornvaleSaveV2 {
  return {
    version: 2,
    savedAt: Date.now(),
    zoneId,
    spawnPoint,
    inventory: { wood_log: 4, stone_shard: 2 },
    equipped: {},
    unlockedRecipes: [],
    discoveredLocations: [zoneId],
    constructions: [],
    defeatedUniqueIds: [],
    playerHealthRatio: 1,
  };
}

export function migrateSaveData(raw: unknown): ThornvaleSaveV2 {
  const fallback = createDefaultSave();
  if (!raw || typeof raw !== 'object') return fallback;
  const obj = raw as Record<string, unknown>;

  return {
    version: 2,
    savedAt: typeof obj.savedAt === 'number' ? obj.savedAt : Date.now(),
    zoneId: typeof obj.zoneId === 'string' ? obj.zoneId : fallback.zoneId,
    spawnPoint:
      Array.isArray(obj.spawnPoint) && obj.spawnPoint.length === 3
        ? [Number(obj.spawnPoint[0]) || 0, Number(obj.spawnPoint[1]) || 0, Number(obj.spawnPoint[2]) || 0]
        : fallback.spawnPoint,
    inventory:
      obj.inventory && typeof obj.inventory === 'object'
        ? (obj.inventory as Record<string, number>)
        : fallback.inventory,
    equipped:
      obj.equipped && typeof obj.equipped === 'object'
        ? (obj.equipped as ThornvaleSaveV2['equipped'])
        : {},
    unlockedRecipes: Array.isArray(obj.unlockedRecipes)
      ? obj.unlockedRecipes.filter((x): x is string => typeof x === 'string')
      : [],
    discoveredLocations: Array.isArray(obj.discoveredLocations)
      ? obj.discoveredLocations.filter((x): x is string => typeof x === 'string')
      : fallback.discoveredLocations,
    constructions: Array.isArray(obj.constructions)
      ? (obj.constructions as ThornvaleSaveV2['constructions'])
      : [],
    defeatedUniqueIds: Array.isArray(obj.defeatedUniqueIds)
      ? obj.defeatedUniqueIds.filter((x): x is string => typeof x === 'string')
      : [],
    playerHealthRatio:
      typeof obj.playerHealthRatio === 'number'
        ? Math.max(0.1, Math.min(1, obj.playerHealthRatio))
        : 1,
  };
}

export function readNormalSave(): ThornvaleSaveV2 {
  try {
    const rawStr = localStorage.getItem(STORAGE_KEY);
    if (!rawStr) return createDefaultSave();
    return migrateSaveData(JSON.parse(rawStr));
  } catch {
    return createDefaultSave();
  }
}

export function writeNormalSave(data: ThornvaleSaveV2): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...data, version: 2, savedAt: Date.now() }));
  } catch {
    // Ignore storage quota errors
  }
}
