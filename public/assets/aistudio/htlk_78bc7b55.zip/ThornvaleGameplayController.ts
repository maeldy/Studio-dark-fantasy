import * as THREE from 'three';
import { WEAPONS } from '../data/itemsCatalog';
import { CombatSystem, DamageableTarget } from '../systems/CombatSystem';
import { ConstructionSystem, TerrainQuery } from '../systems/ConstructionSystem';
import { CraftingSystem } from '../systems/CraftingSystem';
import { DevSandboxIsolation } from '../systems/DevSandboxIsolation';
import { EquipmentSystem, InventoryPort } from '../systems/EquipmentSystem';
import { readNormalSave } from '../systems/SaveMigrationSystem';
import { BuildableType, ThornvaleSaveV2, WeaponSpec } from '../types/gameplay';
import { createLowPolyBuildableMesh } from '../visuals/LowPolyGearBuilder';

const FIST_FALLBACK_WEAPON: WeaponSpec = {
  id: 'bare_hands',
  name: 'Mains nues',
  category: 'dagger',
  damage: 4,
  range: 1.6,
  windupSec: 0.12,
  activeSec: 0.12,
  recoverySec: 0.2,
  staminaCost: 8,
  comboWindowSec: 0.5,
  maxCombo: 2,
  knockback: 1.0,
  materialTone: 'leather',
};

export class ThornvaleGameplayController {
  public readonly combat: CombatSystem;
  public readonly equipment: EquipmentSystem;
  public readonly crafting: CraftingSystem;
  public readonly construction: ConstructionSystem;
  public readonly devIsolation: DevSandboxIsolation;

  private currentZoneId = 'thornvale_forest';
  private spawnPoint = new THREE.Vector3(0, 0, 0);

  constructor(
    scene: THREE.Scene,
    private inventory: InventoryPort,
    terrain: TerrainQuery
  ) {
    this.combat = new CombatSystem();
    this.equipment = new EquipmentSystem(inventory);
    this.crafting = new CraftingSystem(inventory);
    this.construction = new ConstructionSystem(
      scene,
      inventory,
      terrain,
      (type) => createLowPolyBuildableMesh(type)
    );
    this.devIsolation = new DevSandboxIsolation();
    this.hydrateFromSave(readNormalSave());
  }

  public getActiveWeapon(): WeaponSpec {
    const id = this.equipment.getEquipped().main_hand;
    return (id && WEAPONS[id]) || FIST_FALLBACK_WEAPON;
  }

  public recalculateStats(): void {
    const totals = this.equipment.computeTotals();
    this.combat.setBaseStats(100, 6, totals.defense, Math.max(40, 100 + totals.staminaDelta));
  }

  public hydrateFromSave(save: ThornvaleSaveV2): void {
    this.currentZoneId = save.zoneId;
    this.spawnPoint.set(...save.spawnPoint);
    this.inventory.replaceAll?.(save.inventory);
    this.equipment.setEquippedMap(save.equipped);
    this.crafting.setUnlockedRecipes(save.unlockedRecipes);
    this.construction.loadZoneRecords(save.constructions, save.zoneId);
    this.recalculateStats();
    this.combat.hp = Math.max(10, Math.round(this.combat.maxHp * save.playerHealthRatio));
  }

  public exportCurrentState(discoveredLocations: string[], defeatedUniqueIds: string[]): ThornvaleSaveV2 {
    return {
      version: 2,
      savedAt: Date.now(),
      zoneId: this.currentZoneId,
      spawnPoint: [this.spawnPoint.x, this.spawnPoint.y, this.spawnPoint.z],
      inventory: this.inventory.exportAll ? this.inventory.exportAll() : {},
      equipped: this.equipment.getEquipped(),
      unlockedRecipes: this.crafting.getUnlockedRecipeIds(),
      discoveredLocations,
      constructions: this.construction.exportRecords(),
      defeatedUniqueIds,
      playerHealthRatio: this.combat.maxHp > 0 ? this.combat.hp / this.combat.maxHp : 1,
    };
  }

  public saveProgress(discoveredLocations: string[] = [this.currentZoneId], defeatedUniqueIds: string[] = []): void {
    this.devIsolation.persistState(this.exportCurrentState(discoveredLocations, defeatedUniqueIds));
  }

  public enterDevMode(): void {
    const devState = this.devIsolation.activateDevMode();
    this.hydrateFromSave(devState);
  }

  public exitDevMode(): void {
    const restored = this.devIsolation.deactivateDevModeAndRestore();
    this.hydrateFromSave(restored);
  }

  public spawnBuildableInDev(type: BuildableType, pos: THREE.Vector3): void {
    if (!this.devIsolation.isDevModeActive()) return;
    this.construction.spawnDirectInDev(type, pos, this.currentZoneId);
  }

  public tick(
    dt: number,
    playerPos: THREE.Vector3,
    forwardDir: THREE.Vector3,
    targets: DamageableTarget[]
  ): void {
    this.combat.update(dt, playerPos, forwardDir, this.getActiveWeapon(), targets);
  }
}
