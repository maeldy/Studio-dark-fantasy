import * as THREE from 'three';
import { CombatStats, WeaponSpec } from '../types/gameplay';

export type AttackPhase = 'idle' | 'windup' | 'active' | 'recovery';

export interface DamageableTarget {
  id: string;
  position: THREE.Vector3;
  radius: number;
  applyDamage: (amount: number, knockbackDir: THREE.Vector3, sourceId: string) => void;
}

export interface CombatHooks {
  onPhaseChange?: (phase: AttackPhase, comboIndex: number, weapon: WeaponSpec) => void;
  onHitTarget?: (targetId: string, damage: number, parried: boolean) => void;
  onPlayerDamaged?: (amount: number, interrupted: boolean) => void;
  onPlayerDeath?: () => void;
  hasLineOfSight?: (from: THREE.Vector3, to: THREE.Vector3) => boolean;
}

export class CombatSystem {
  private phase: AttackPhase = 'idle';
  private phaseTimer = 0;
  private comboStep = 0;
  private comboResetTimer = 0;
  private hitTargetIdsThisSwing = new Set<string>();

  private blockHoldTimer = 0;
  private dodgeTimer = 0;
  private dodgeCooldown = 0;
  private staggerTimer = 0;
  private invulnTimer = 0;

  public hp = 100;
  public maxHp = 100;
  public stamina = 100;
  public maxStamina = 100;
  public baseDamage = 8;
  public defense = 0;
  public isBlocking = false;
  public isDead = false;

  constructor(private hooks: CombatHooks = {}) {}

  public getSnapshotStats(weaponDamage = 0): CombatStats {
    return {
      hp: this.hp,
      maxHp: this.maxHp,
      stamina: this.stamina,
      maxStamina: this.maxStamina,
      attackDamage: this.baseDamage + weaponDamage,
      defense: this.defense,
      isBlocking: this.isBlocking,
      isParryWindow: this.isBlocking && this.blockHoldTimer <= 0.22,
      isDodging: this.dodgeTimer > 0,
      isDead: this.isDead,
    };
  }

  public setBaseStats(maxHp: number, attackDamage: number, defense: number, maxStamina = 100): void {
    const ratio = this.maxHp > 0 ? this.hp / this.maxHp : 1;
    this.maxHp = Math.max(1, maxHp);
    this.maxStamina = Math.max(20, maxStamina);
    this.hp = this.isDead ? 0 : Math.min(this.maxHp, Math.max(1, Math.round(this.maxHp * ratio)));
    this.stamina = Math.min(this.maxStamina, this.stamina);
    this.baseDamage = attackDamage;
    this.defense = defense;
  }

  public requestAttack(weapon: WeaponSpec): boolean {
    if (this.isDead || this.staggerTimer > 0 || this.dodgeTimer > 0) return false;
    if (this.phase !== 'idle') return false;
    if (this.stamina < weapon.staminaCost) return false;

    this.stamina -= weapon.staminaCost;
    this.isBlocking = false;
    this.blockHoldTimer = 0;
    this.comboStep = this.comboResetTimer > 0 ? (this.comboStep % weapon.maxCombo) + 1 : 1;
    this.phase = 'windup';
    this.phaseTimer = weapon.windupSec;
    this.hitTargetIdsThisSwing.clear();
    this.hooks.onPhaseChange?.(this.phase, this.comboStep, weapon);
    return true;
  }

  public setBlocking(active: boolean): void {
    if (this.isDead || this.staggerTimer > 0 || this.dodgeTimer > 0) {
      this.isBlocking = false;
      this.blockHoldTimer = 0;
      return;
    }
    if (active && !this.isBlocking && this.phase === 'idle') {
      this.isBlocking = true;
      this.blockHoldTimer = 0;
    } else if (!active) {
      this.isBlocking = false;
      this.blockHoldTimer = 0;
    }
  }

  public requestDodge(): boolean {
    if (this.isDead || this.dodgeTimer > 0 || this.dodgeCooldown > 0) return false;
    const cost = 18;
    if (this.stamina < cost) return false;

    this.stamina -= cost;
    this.phase = 'idle';
    this.phaseTimer = 0;
    this.isBlocking = false;
    this.dodgeTimer = 0.28;
    this.dodgeCooldown = 0.45;
    this.invulnTimer = 0.22;
    return true;
  }

  public receiveEnemyHit(
    rawDamage: number,
    _attackerPos: THREE.Vector3,
    _playerPos: THREE.Vector3,
    staggerPower = 1
  ): { blocked: boolean; parried: boolean; damageTaken: number } {
    if (this.isDead || this.invulnTimer > 0) {
      return { blocked: false, parried: false, damageTaken: 0 };
    }

    if (this.isBlocking && this.stamina >= 6) {
      const isParry = this.blockHoldTimer <= 0.22;
      const staminaDrain = isParry ? 6 : Math.max(8, Math.round(rawDamage * 0.7));
      this.stamina = Math.max(0, this.stamina - staminaDrain);
      if (isParry) {
        this.invulnTimer = 0.35;
        return { blocked: true, parried: true, damageTaken: 0 };
      }
      const reduced = Math.max(1, Math.round(rawDamage * 0.25 - this.defense * 0.2));
      this.hp = Math.max(0, this.hp - reduced);
      if (this.hp <= 0) this.triggerDeath();
      return { blocked: true, parried: false, damageTaken: reduced };
    }

    const mitigated = Math.max(1, Math.round(rawDamage - this.defense * 0.65));
    this.hp = Math.max(0, this.hp - mitigated);
    const interrupted = staggerPower >= 2 || mitigated >= 12;
    if (interrupted) {
      this.phase = 'idle';
      this.phaseTimer = 0;
      this.staggerTimer = 0.32;
    }
    this.invulnTimer = 0.25;
    this.hooks.onPlayerDamaged?.(mitigated, interrupted);

    if (this.hp <= 0) {
      this.triggerDeath();
    }
    return { blocked: false, parried: false, damageTaken: mitigated };
  }

  private triggerDeath(): void {
    if (this.isDead) return;
    this.isDead = true;
    this.phase = 'idle';
    this.isBlocking = false;
    this.hooks.onPlayerDeath?.();
  }

  public respawnAt(spawnPos: THREE.Vector3, playerObj: THREE.Object3D, healthRatio = 1): void {
    this.isDead = false;
    this.phase = 'idle';
    this.phaseTimer = 0;
    this.comboStep = 0;
    this.staggerTimer = 0;
    this.invulnTimer = 0.75;
    this.hp = Math.max(10, Math.round(this.maxHp * THREE.MathUtils.clamp(healthRatio, 0.25, 1)));
    this.stamina = this.maxStamina;
    playerObj.position.copy(spawnPos);
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    forwardDir: THREE.Vector3,
    weapon: WeaponSpec,
    targets: DamageableTarget[]
  ): void {
    if (this.isDead) return;

    this.invulnTimer = Math.max(0, this.invulnTimer - dt);
    this.dodgeCooldown = Math.max(0, this.dodgeCooldown - dt);
    if (this.dodgeTimer > 0) this.dodgeTimer = Math.max(0, this.dodgeTimer - dt);
    if (this.staggerTimer > 0) this.staggerTimer = Math.max(0, this.staggerTimer - dt);
    if (this.isBlocking) this.blockHoldTimer += dt;

    if (this.phase === 'idle' && !this.isBlocking && this.dodgeTimer === 0) {
      this.comboResetTimer = Math.max(0, this.comboResetTimer - dt);
      this.stamina = Math.min(this.maxStamina, this.stamina + 18 * dt);
      return;
    }

    if (this.phase !== 'idle') {
      this.phaseTimer -= dt;
      if (this.phase === 'active') {
        this.evaluateHits(playerPos, forwardDir, weapon, targets);
      }
      if (this.phaseTimer <= 0) {
        this.advancePhase(weapon);
      }
    }
  }

  private advancePhase(weapon: WeaponSpec): void {
    if (this.phase === 'windup') {
      this.phase = 'active';
      this.phaseTimer = weapon.activeSec;
      this.hooks.onPhaseChange?.(this.phase, this.comboStep, weapon);
    } else if (this.phase === 'active') {
      this.phase = 'recovery';
      this.phaseTimer = weapon.recoverySec;
      this.comboResetTimer = weapon.comboWindowSec;
      this.hooks.onPhaseChange?.(this.phase, this.comboStep, weapon);
    } else if (this.phase === 'recovery') {
      this.phase = 'idle';
      this.phaseTimer = 0;
      this.hooks.onPhaseChange?.(this.phase, this.comboStep, weapon);
    }
  }

  private evaluateHits(
    playerPos: THREE.Vector3,
    forwardDir: THREE.Vector3,
    weapon: WeaponSpec,
    targets: DamageableTarget[]
  ): void {
    const fwd = forwardDir.clone().setY(0).normalize();
    const comboMult = 1 + (this.comboStep - 1) * 0.15;
    const totalDamage = Math.round((this.baseDamage + weapon.damage) * comboMult);

    for (const target of targets) {
      if (this.hitTargetIdsThisSwing.has(target.id)) continue;

      const toTarget = new THREE.Vector3().subVectors(target.position, playerPos);
      toTarget.y = 0;
      const dist = toTarget.length();
      if (dist > weapon.range + target.radius) continue;

      const dirNorm = dist > 0.0001 ? toTarget.clone().divideScalar(dist) : fwd;
      const dot = fwd.dot(dirNorm);
      const minDot = weapon.category === 'spear' ? 0.78 : 0.35;
      if (dot < minDot) continue;

      if (this.hooks.hasLineOfSight && !this.hooks.hasLineOfSight(playerPos, target.position)) {
        continue;
      }

      this.hitTargetIdsThisSwing.add(target.id);
      target.applyDamage(totalDamage, dirNorm.multiplyScalar(weapon.knockback), 'player');
      this.hooks.onHitTarget?.(target.id, totalDamage, false);
    }
  }
}
