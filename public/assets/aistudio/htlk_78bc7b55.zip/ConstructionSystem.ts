import * as THREE from 'three';
import { BUILDABLES } from '../data/buildablesCatalog';
import { BuildableType, PlacedConstructionRecord } from '../types/gameplay';
import { InventoryPort } from './EquipmentSystem';

export interface TerrainQuery {
  sampleHeightAndNormal: (x: number, z: number) => { y: number; normal: THREE.Vector3 } | null;
  hasBlockingObstacle: (pos: THREE.Vector3, radius: number) => boolean;
}

export class ConstructionSystem {
  private activeType: BuildableType | null = null;
  private previewMesh: THREE.Mesh;
  private records: PlacedConstructionRecord[] = [];
  private spawnedMeshes = new Map<string, THREE.Object3D>();

  constructor(
    private scene: THREE.Scene,
    private inventory: InventoryPort,
    private terrain: TerrainQuery,
    private buildMeshForType: (type: BuildableType) => THREE.Object3D
  ) {
    const geo = new THREE.CylinderGeometry(1, 1, 0.25, 8);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x55aa66,
      transparent: true,
      opacity: 0.45,
    });
    this.previewMesh = new THREE.Mesh(geo, mat);
    this.previewMesh.visible = false;
    this.scene.add(this.previewMesh);
  }

  public getActiveType(): BuildableType | null {
    return this.activeType;
  }

  public startPlacement(type: BuildableType): void {
    this.activeType = type;
    const spec = BUILDABLES[type];
    this.previewMesh.scale.set(spec.footprintRadius, 1, spec.footprintRadius);
    this.previewMesh.visible = true;
  }

  public cancelPlacement(): void {
    this.activeType = null;
    this.previewMesh.visible = false;
  }

  public evaluatePlacement(
    candidatePos: THREE.Vector3,
    type: BuildableType
  ): { valid: boolean; snappedPos: THREE.Vector3; reason?: string } {
    const spec = BUILDABLES[type];
    const sampled = this.terrain.sampleHeightAndNormal(candidatePos.x, candidatePos.z);
    if (!sampled) {
      return { valid: false, snappedPos: candidatePos.clone(), reason: 'Surface hors terrain.' };
    }

    const snapped = new THREE.Vector3(candidatePos.x, sampled.y, candidatePos.z);
    if (sampled.normal.y < spec.maxSlopeCos) {
      return { valid: false, snappedPos: snapped, reason: 'Terrain trop incliné.' };
    }

    if (this.terrain.hasBlockingObstacle(snapped, spec.footprintRadius)) {
      return { valid: false, snappedPos: snapped, reason: 'Obstacle ou collision présente.' };
    }

    for (const existing of this.records) {
      const exSpec = BUILDABLES[existing.type];
      const dx = existing.position[0] - snapped.x;
      const dz = existing.position[2] - snapped.z;
      const minDist = spec.footprintRadius + exSpec.footprintRadius;
      if (dx * dx + dz * dz < minDist * minDist) {
        return { valid: false, snappedPos: snapped, reason: 'Chevauchement d’une construction.' };
      }
    }

    return { valid: true, snappedPos: snapped };
  }

  public updatePreview(candidatePos: THREE.Vector3): boolean {
    if (!this.activeType) return false;
    const res = this.evaluatePlacement(candidatePos, this.activeType);
    this.previewMesh.position.copy(res.snappedPos).add(new THREE.Vector3(0, 0.12, 0));
    const mat = this.previewMesh.material as THREE.MeshBasicMaterial;
    mat.color.setHex(res.valid ? 0x55aa66 : 0xbb3333);
    return res.valid;
  }

  public confirmPlacement(
    candidatePos: THREE.Vector3,
    zoneId: string,
    rotationY = 0
  ): { ok: boolean; record?: PlacedConstructionRecord; error?: string } {
    if (!this.activeType) return { ok: false, error: 'Aucune construction sélectionnée.' };
    const type = this.activeType;
    const spec = BUILDABLES[type];

    for (const ing of spec.cost) {
      if (this.inventory.getCount(ing.itemId) < ing.quantity) {
        return { ok: false, error: 'Matériaux insuffisants.' };
      }
    }

    const check = this.evaluatePlacement(candidatePos, type);
    if (!check.valid) {
      return { ok: false, error: check.reason ?? 'Emplacement invalide.' };
    }

    for (const ing of spec.cost) {
      this.inventory.removeItem(ing.itemId, ing.quantity);
    }

    const record: PlacedConstructionRecord = {
      uid: `b_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      type,
      zoneId,
      position: [check.snappedPos.x, check.snappedPos.y, check.snappedPos.z],
      rotationY,
      state: {},
    };

    this.addRecordAndMesh(record, zoneId);
    this.cancelPlacement();
    return { ok: true, record };
  }

  public spawnDirectInDev(type: BuildableType, pos: THREE.Vector3, zoneId: string, rotationY = 0): PlacedConstructionRecord {
    const record: PlacedConstructionRecord = {
      uid: `dev_b_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      type,
      zoneId,
      position: [pos.x, pos.y, pos.z],
      rotationY,
      state: { devSpawned: true },
    };
    this.addRecordAndMesh(record, zoneId);
    return record;
  }

  public loadZoneRecords(records: PlacedConstructionRecord[], currentZoneId: string): void {
    this.clearMeshes();
    this.records = [...records];
    for (const rec of this.records) {
      if (rec.zoneId === currentZoneId) {
        this.spawnMesh(rec);
      }
    }
  }

  public exportRecords(): PlacedConstructionRecord[] {
    return this.records.map((r) => ({ ...r, position: [...r.position] as [number, number, number] }));
  }

  private addRecordAndMesh(rec: PlacedConstructionRecord, currentZoneId: string): void {
    this.records.push(rec);
    if (rec.zoneId === currentZoneId) {
      this.spawnMesh(rec);
    }
  }

  private spawnMesh(rec: PlacedConstructionRecord): void {
    if (this.spawnedMeshes.has(rec.uid)) return;
    const obj = this.buildMeshForType(rec.type);
    obj.position.set(rec.position[0], rec.position[1], rec.position[2]);
    obj.rotation.y = rec.rotationY;
    this.scene.add(obj);
    this.spawnedMeshes.set(rec.uid, obj);
  }

  private clearMeshes(): void {
    for (const obj of this.spawnedMeshes.values()) {
      this.scene.remove(obj);
    }
    this.spawnedMeshes.clear();
  }
}
