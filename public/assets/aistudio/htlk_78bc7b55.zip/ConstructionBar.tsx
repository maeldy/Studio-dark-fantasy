import React from 'react';
import { Check, X } from 'lucide-react';
import { BUILDABLES } from '../data/buildablesCatalog';
import { ITEM_LABELS } from '../data/itemsCatalog';
import { BuildableType } from '../types/gameplay';

interface ConstructionBarProps {
  open: boolean;
  selectedType: BuildableType | null;
  placementValid: boolean;
  getItemCount: (itemId: string) => number;
  onSelectType: (type: BuildableType) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConstructionBar: React.FC<ConstructionBarProps> = ({
  open,
  selectedType,
  placementValid,
  getItemCount,
  onSelectType,
  onConfirm,
  onCancel,
}) => {
  if (!open) return null;

  return (
    <div className="pointer-events-auto fixed bottom-20 left-1/2 z-30 w-[94vw] max-w-xl -translate-x-1/2 rounded border border-[#6a6152] bg-[#16191c]/95 p-2.5 text-xs text-[#e6e1d6] shadow-lg">
      <div className="flex gap-2 overflow-x-auto pb-1.5">
        {Object.values(BUILDABLES).map((b) => {
          const active = selectedType === b.type;
          return (
            <button
              key={b.type}
              type="button"
              onClick={() => onSelectType(b.type)}
              className={`shrink-0 rounded border px-2.5 py-2 text-left ${
                active
                  ? 'border-[#d4b06a] bg-[#2d261a]'
                  : 'border-[#3d3932] bg-[#1f2226]'
              }`}
            >
              <div className="font-semibold">{b.label}</div>
              <div className="mt-0.5 text-[10px] text-[#b3aca0]">
                {b.cost
                  .map((c) => `${ITEM_LABELS[c.itemId] ?? c.itemId}: ${getItemCount(c.itemId)}/${c.quantity}`)
                  .join(' · ')}
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-2 flex items-center justify-end gap-2 border-t border-[#2f2d28] pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="flex min-h-10 items-center gap-1 rounded border border-[#524c42] bg-[#23262a] px-3 py-1.5"
        >
          <X className="h-4 w-4" />
          <span>Fermer</span>
        </button>
        {selectedType && (
          <button
            type="button"
            disabled={!placementValid}
            onClick={onConfirm}
            className={`flex min-h-10 items-center gap-1 rounded px-3 py-1.5 font-semibold ${
              placementValid
                ? 'border border-[#6f9c5b] bg-[#21331c] text-[#cbe8be]'
                : 'cursor-not-allowed border border-[#4a3230] bg-[#291b1a] text-[#9e7773]'
            }`}
          >
            <Check className="h-4 w-4" />
            <span>Placer</span>
          </button>
        )}
      </div>
    </div>
  );
};
