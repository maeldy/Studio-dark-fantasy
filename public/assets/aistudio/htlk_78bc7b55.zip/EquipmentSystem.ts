import { ARMORS, WEAPONS } from '../data/itemsCatalog';
import { EquipmentSlot } from '../types/gameplay';

export interface InventoryPort {
  getCount(itemId: string): number;
  addItem(itemId: string, qty: number): void;
  removeItem(itemId: string, qty: number): boolean;
  exportAll?: () => Record<string, number>;
  replaceAll?: (map: Record<string, number>) => void;
}

export class EquipmentSystem {
  private equipped: Partial<Record<EquipmentSlot, string>> = {};

  constructor(private inventory: InventoryPort) {}

  public getEquipped(): Partial<Record<EquipmentSlot, string>> {
    return { ...this.equipped };
  }

  public setEquippedMap(map: Partial<Record<EquipmentSlot, string>>): void {
    this.equipped = { ...map };
  }

  public equipItem(itemId: string): boolean {
    if (this.inventory.getCount(itemId) <= 0) return false;

    const weapon = WEAPONS[itemId];
    if (weapon) {
      this.equipped.main_hand = itemId;
      return true;
    }

    const armor = ARMORS[itemId];
    if (armor) {
      this.equipped[armor.slot] = itemId;
      return true;
    }

    return false;
  }

  public unequipSlot(slot: EquipmentSlot): boolean {
    if (!this.equipped[slot]) return false;
    delete this.equipped[slot];
    return true;
  }

  public computeTotals(): {
    weaponDamage: number;
    defense: number;
    staminaDelta: number;
  } {
    let weaponDamage = 0;
    let defense = 0;
    let staminaDelta = 0;

    const weaponId = this.equipped.main_hand;
    if (weaponId && WEAPONS[weaponId]) {
      weaponDamage += WEAPONS[weaponId].damage;
    }

    (Object.keys(this.equipped) as EquipmentSlot[]).forEach((slot) => {
      if (slot === 'main_hand') return;
      const id = this.equipped[slot];
      const spec = id ? ARMORS[id] : undefined;
      if (spec) {
        defense += spec.defense;
        staminaDelta += spec.staminaMod ?? 0;
      }
    });

    return { weaponDamage, defense, staminaDelta };
  }
}
