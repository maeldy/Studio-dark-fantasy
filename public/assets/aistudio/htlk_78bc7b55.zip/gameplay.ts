export type WeaponCategory =
  | 'short_sword'
  | 'long_sword'
  | 'dagger'
  | 'axe'
  | 'mace'
  | 'spear'
  | 'bow';

export type ArmorCategory =
  | 'cloth'
  | 'leather'
  | 'reinforced_leather'
  | 'chainmail'
  | 'plate'
  | 'helmet'
  | 'shield';

export type EquipmentSlot =
  | 'head'
  | 'chest'
  | 'legs'
  | 'feet'
  | 'main_hand'
  | 'off_hand_shield';

export type ToolKind = 'axe' | 'pickaxe' | 'knife' | 'utility';
export type ToolQuality = 'crude' | 'iron' | 'tempered';

export type StationType = 'none' | 'workbench' | 'forge' | 'furnace' | 'anvil';

export type BuildableType =
  | 'campfire'
  | 'storage_chest'
  | 'workbench'
  | 'small_barrier'
  | 'palisade'
  | 'wood_beam_frame'
  | 'utility_shelter';

export interface WeaponSpec {
  id: string;
  name: string;
  category: WeaponCategory;
  damage: number;
  range: number;
  windupSec: number;
  activeSec: number;
  recoverySec: number;
  staminaCost: number;
  comboWindowSec: number;
  maxCombo: number;
  knockback: number;
  materialTone: 'wood' | 'stone' | 'iron' | 'steel' | 'leather';
}

export interface ArmorSpec {
  id: string;
  name: string;
  category: ArmorCategory;
  slot: EquipmentSlot;
  defense: number;
  staminaMod?: number;
  materialTone: 'cloth' | 'leather' | 'iron' | 'steel' | 'wood';
}

export interface ToolSpec {
  id: string;
  name: string;
  kind: ToolKind;
  quality: ToolQuality;
  harvestPower: number;
  speedMultiplier: number;
  staminaPerSwing: number;
}

export interface RecipeIngredient {
  itemId: string;
  quantity: number;
}

export interface CraftingRecipe {
  id: string;
  resultItemId: string;
  resultQuantity: number;
  station: StationType;
  ingredients: RecipeIngredient[];
  unlockedByDefault: boolean;
  unlockHint?: string;
}

export interface CombatStats {
  hp: number;
  maxHp: number;
  stamina: number;
  maxStamina: number;
  attackDamage: number;
  defense: number;
  isBlocking: boolean;
  isParryWindow: boolean;
  isDodging: boolean;
  isDead: boolean;
}

export interface PlacedConstructionRecord {
  uid: string;
  type: BuildableType;
  zoneId: string;
  position: [number, number, number];
  rotationY: number;
  state: Record<string, unknown>;
}

export interface ThornvaleSaveV2 {
  version: 2;
  savedAt: number;
  zoneId: string;
  spawnPoint: [number, number, number];
  inventory: Record<string, number>;
  equipped: Partial<Record<EquipmentSlot, string>>;
  unlockedRecipes: string[];
  discoveredLocations: string[];
  constructions: PlacedConstructionRecord[];
  defeatedUniqueIds: string[];
  playerHealthRatio: number;
}
