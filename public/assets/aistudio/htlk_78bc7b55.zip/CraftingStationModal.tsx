import React from 'react';
import { X, Hammer } from 'lucide-react';
import { ITEM_LABELS } from '../data/itemsCatalog';
import { CraftingRecipe, StationType } from '../types/gameplay';

const STATION_NAMES: Record<StationType, string> = {
  none: 'Fabrication manuelle',
  workbench: 'Établi',
  forge: 'Forge',
  furnace: 'Fourneau',
  anvil: 'Enclume',
};

interface CraftingStationModalProps {
  open: boolean;
  station: StationType;
  recipes: CraftingRecipe[];
  getItemCount: (itemId: string) => number;
  canCraft: (recipe: CraftingRecipe) => boolean;
  onCraft: (recipeId: string) => void;
  onClose: () => void;
}

export const CraftingStationModal: React.FC<CraftingStationModalProps> = ({
  open,
  station,
  recipes,
  getItemCount,
  canCraft,
  onCraft,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-3">
      <div className="max-h-[85vh] w-full max-w-md overflow-y-auto rounded border border-[#6a6152] bg-[#17191c] p-4 text-[#e6e1d6] shadow-xl">
        <div className="mb-3 flex items-center justify-between border-b border-[#32302b] pb-2">
          <div className="flex items-center gap-2 font-semibold">
            <Hammer className="h-4 w-4 text-[#c9a66b]" />
            <span>{STATION_NAMES[station]}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded border border-[#4a453c] bg-[#22252a]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-2.5">
          {recipes.length === 0 && (
            <p className="text-xs text-[#9c9588]">Aucune recette débloquée pour cette installation.</p>
          )}
          {recipes.map((r) => {
            const craftable = canCraft(r);
            return (
              <div
                key={r.id}
                className="flex items-center justify-between gap-3 rounded border border-[#36332d] bg-[#1e2125] p-2.5"
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">
                    {ITEM_LABELS[r.resultItemId] ?? r.resultItemId} ×{r.resultQuantity}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1.5 text-[11px] text-[#b3aca0]">
                    {r.ingredients.map((ing) => {
                      const owned = getItemCount(ing.itemId);
                      const ok = owned >= ing.quantity;
                      return (
                        <span
                          key={ing.itemId}
                          className={ok ? 'text-[#9cb578]' : 'text-[#c46b5e]'}
                        >
                          {ITEM_LABELS[ing.itemId] ?? ing.itemId} ({owned}/{ing.quantity})
                        </span>
                      );
                    })}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={!craftable}
                  onClick={() => onCraft(r.id)}
                  className={`min-h-10 rounded px-3 py-1.5 text-xs font-semibold ${
                    craftable
                      ? 'border border-[#8c7246] bg-[#362c1c] text-[#f3dfb6] active:scale-95'
                      : 'cursor-not-allowed border border-[#34322e] bg-[#23262a] text-[#6e6a63]'
                  }`}
                >
                  Fabriquer
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
