import React, { useState } from 'react';
import { ARMORS, TOOLS, WEAPONS } from '../data/itemsCatalog';
import { BUILDABLES } from '../data/buildablesCatalog';
import { BuildableType } from '../types/gameplay';

interface DevGameplayPanelProps {
  open: boolean;
  onSpawnItemAndEquip: (itemId: string) => void;
  onGiveResources: () => void;
  onSpawnBuildableHere: (type: BuildableType) => void;
  onHealFull: () => void;
  onSimulateEnemyHit: (dmg: number) => void;
}

export const DevGameplayPanel: React.FC<DevGameplayPanelProps> = ({
  open,
  onSpawnItemAndEquip,
  onGiveResources,
  onSpawnBuildableHere,
  onHealFull,
  onSimulateEnemyHit,
}) => {
  const [selectedWeapon, setSelectedWeapon] = useState('thorn_short_sword');
  const [selectedArmor, setSelectedArmor] = useState('iron_chainmail');
  const [selectedTool, setSelectedTool] = useState('iron_axe');
  const [selectedBuild, setSelectedBuild] = useState<BuildableType>('campfire');

  if (!open) return null;

  return (
    <div className="pointer-events-auto fixed left-3 top-36 z-30 w-64 space-y-2.5 rounded border border-[#8c6b36] bg-[#171614]/95 p-3 text-xs text-[#ece5d8] shadow-xl">
      <div className="font-semibold text-[#f3cf8b]">Outils Développeur Gameplay</div>

      <div className="space-y-1">
        <label className="block text-[11px] text-[#b8b0a2]">Arme</label>
        <div className="flex gap-1">
          <select
            value={selectedWeapon}
            onChange={(e) => setSelectedWeapon(e.target.value)}
            className="min-w-0 flex-1 rounded border border-[#4a4337] bg-[#22201d] px-1.5 py-1"
          >
            {Object.values(WEAPONS).map((w) => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => onSpawnItemAndEquip(selectedWeapon)}
            className="rounded border border-[#7c653d] bg-[#332918] px-2 py-1 font-medium"
          >
            Équiper
          </button>
        </div>
      </div>

      <div className="space-y-1">
        <label className="block text-[11px] text-[#b8b0a2]">Armure / Bouclier</label>
        <div className="flex gap-1">
          <select
            value={selectedArmor}
            onChange={(e) => setSelectedArmor(e.target.value)}
            className="min-w-0 flex-1 rounded border border-[#4a4337] bg-[#22201d] px-1.5 py-1"
          >
            {Object.values(ARMORS).map((a) => (
              <option key={a.id} value={a.id}>{a.name}</option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => onSpawnItemAndEquip(selectedArmor)}
            className="rounded border border-[#7c653d] bg-[#332918] px-2 py-1 font-medium"
          >
            Équiper
          </button>
        </div>
      </div>

      <div className="space-y-1">
        <label className="block text-[11px] text-[#b8b0a2]">Outil de récolte</label>
        <div className="flex gap-1">
          <select
            value={selectedTool}
            onChange={(e) => setSelectedTool(e.target.value)}
            className="min-w-0 flex-1 rounded border border-[#4a4337] bg-[#22201d] px-1.5 py-1"
          >
            {Object.values(TOOLS).map((t) => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => onSpawnItemAndEquip(selectedTool)}
            className="rounded border border-[#7c653d] bg-[#332918] px-2 py-1 font-medium"
          >
            Ajouter
          </button>
        </div>
      </div>

      <div className="space-y-1">
        <label className="block text-[11px] text-[#b8b0a2]">Construction immédiate</label>
        <div className="flex gap-1">
          <select
            value={selectedBuild}
            onChange={(e) => setSelectedBuild(e.target.value as BuildableType)}
            className="min-w-0 flex-1 rounded border border-[#4a4337] bg-[#22201d] px-1.5 py-1"
          >
            {Object.values(BUILDABLES).map((b) => (
              <option key={b.type} value={b.type}>{b.label}</option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => onSpawnBuildableHere(selectedBuild)}
            className="rounded border border-[#7c653d] bg-[#332918] px-2 py-1 font-medium"
          >
            Poser
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-1 pt-1">
        <button
          type="button"
          onClick={onGiveResources}
          className="rounded border border-[#524c42] bg-[#252421] py-1.5 font-medium"
        >
          +Ressources
        </button>
        <button
          type="button"
          onClick={onHealFull}
          className="rounded border border-[#4b6e44] bg-[#1e2d1b] py-1.5 font-medium"
        >
          Soin 100%
        </button>
        <button
          type="button"
          onClick={() => onSimulateEnemyHit(15)}
          className="rounded border border-[#7a3c35] bg-[#2e1917] py-1.5 font-medium"
        >
          Test -15 PV
        </button>
      </div>
    </div>
  );
};
