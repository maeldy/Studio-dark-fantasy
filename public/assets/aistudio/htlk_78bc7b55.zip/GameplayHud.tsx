import React from 'react';
import { Shield, Sword, Footprints, Hammer, Wrench } from 'lucide-react';
import { CombatStats } from '../types/gameplay';

interface GameplayHudProps {
  stats: CombatStats;
  equippedWeaponName: string;
  nearbyStationLabel: string | null;
  devModeActive: boolean;
  onAttack: () => void;
  onBlockStart: () => void;
  onBlockEnd: () => void;
  onDodge: () => void;
  onOpenStation: () => void;
  onToggleBuildBar: () => void;
}

export const GameplayHud: React.FC<GameplayHudProps> = ({
  stats,
  equippedWeaponName,
  nearbyStationLabel,
  devModeActive,
  onAttack,
  onBlockStart,
  onBlockEnd,
  onDodge,
  onOpenStation,
  onToggleBuildBar,
}) => {
  const hpPct = Math.max(0, Math.min(100, (stats.hp / Math.max(1, stats.maxHp)) * 100));
  const stamPct = Math.max(0, Math.min(100, (stats.stamina / Math.max(1, stats.maxStamina)) * 100));

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-3 sm:p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="pointer-events-auto w-56 rounded border border-[#5a5347] bg-[#16191c]/85 p-2.5 text-xs text-[#e6e1d6] shadow-md">
          {devModeActive && (
            <div className="mb-1.5 rounded bg-[#4a3219] px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[#f3cf8b]">
              Bac à sable DEV (sauvegarde isolée)
            </div>
          )}
          <div className="mb-1 flex justify-between font-medium">
            <span>PV</span>
            <span>{stats.hp} / {stats.maxHp}</span>
          </div>
          <div className="mb-2 h-2 w-full overflow-hidden rounded-sm bg-[#2b2a27]">
            <div className="h-full bg-[#9e352b] transition-all duration-100" style={{ width: `${hpPct}%` }} />
          </div>
          <div className="mb-1 flex justify-between font-medium">
            <span>Endurance</span>
            <span>{Math.round(stats.stamina)} / {stats.maxStamina}</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-sm bg-[#2b2a27]">
            <div className="h-full bg-[#7d8f56] transition-all duration-75" style={{ width: `${stamPct}%` }} />
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-[#34312c] pt-1.5 text-[11px] text-[#c7c0b2]">
            <span className="truncate">{equippedWeaponName}</span>
            <span>ATQ {stats.attackDamage} · DÉF {stats.defense}</span>
          </div>
        </div>

        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <button
            type="button"
            onClick={onToggleBuildBar}
            className="flex min-h-11 min-w-11 items-center gap-2 rounded border border-[#6a6152] bg-[#1a1d20]/90 px-3 py-2 text-xs font-medium text-[#e6e1d6] active:scale-95"
          >
            <Hammer className="h-4 w-4 text-[#c9a66b]" />
            <span>Construire</span>
          </button>

          {nearbyStationLabel && (
            <button
              type="button"
              onClick={onOpenStation}
              className="flex min-h-11 items-center gap-2 rounded border border-[#8c7246] bg-[#241e16]/90 px-3 py-2 text-xs font-semibold text-[#f0d9a8] active:scale-95"
            >
              <Wrench className="h-4 w-4" />
              <span>{nearbyStationLabel}</span>
            </button>
          )}
        </div>
      </div>

      <div className="flex items-end justify-end gap-2.5">
        <button
          type="button"
          onClick={onDodge}
          className="pointer-events-auto flex h-13 w-13 items-center justify-center rounded-full border border-[#6a6152] bg-[#181b1e]/85 text-[#e6e1d6] active:scale-95"
          aria-label="Esquiver"
        >
          <Footprints className="h-5 w-5" />
        </button>
        <button
          type="button"
          onPointerDown={onBlockStart}
          onPointerUp={onBlockEnd}
          onPointerLeave={onBlockEnd}
          className={`pointer-events-auto flex h-13 w-13 items-center justify-center rounded-full border active:scale-95 ${
            stats.isBlocking
              ? 'border-[#d4b06a] bg-[#3a301e]/95 text-[#f5dfa9]'
              : 'border-[#6a6152] bg-[#181b1e]/85 text-[#e6e1d6]'
          }`}
          aria-label="Bloquer ou parer"
        >
          <Shield className="h-5 w-5" />
        </button>
        <button
          type="button"
          onClick={onAttack}
          className="pointer-events-auto flex h-15 w-15 items-center justify-center rounded-full border border-[#9e473a] bg-[#2a1715]/90 text-[#f3d8d2] active:scale-95"
          aria-label="Attaquer"
        >
          <Sword className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
};
