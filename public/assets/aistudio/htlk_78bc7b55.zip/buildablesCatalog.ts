import { BuildableType, RecipeIngredient } from '../types/gameplay';

export interface BuildableSpec {
  type: BuildableType;
  label: string;
  cost: RecipeIngredient[];
  maxSlopeCos: number;
  footprintRadius: number;
  blocksMovement: boolean;
}

export const BUILDABLES: Record<BuildableType, BuildableSpec> = {
  campfire: {
    type: 'campfire',
    label: 'Feu de camp',
    cost: [
      { itemId: 'wood_log', quantity: 4 },
      { itemId: 'stone_shard', quantity: 4 },
    ],
    maxSlopeCos: 0.85,
    footprintRadius: 1.0,
    blocksMovement: true,
  },
  storage_chest: {
    type: 'storage_chest',
    label: 'Coffre de rangement',
    cost: [{ itemId: 'wood_log', quantity: 6 }],
    maxSlopeCos: 0.92,
    footprintRadius: 0.9,
    blocksMovement: true,
  },
  workbench: {
    type: 'workbench',
    label: 'Établi',
    cost: [
      { itemId: 'wood_log', quantity: 8 },
      { itemId: 'stone_shard', quantity: 2 },
    ],
    maxSlopeCos: 0.92,
    footprintRadius: 1.2,
    blocksMovement: true,
  },
  small_barrier: {
    type: 'small_barrier',
    label: 'Petite barrière',
    cost: [{ itemId: 'wood_log', quantity: 3 }],
    maxSlopeCos: 0.82,
    footprintRadius: 1.1,
    blocksMovement: true,
  },
  palisade: {
    type: 'palisade',
    label: 'Palissade',
    cost: [{ itemId: 'wood_log', quantity: 5 }],
    maxSlopeCos: 0.82,
    footprintRadius: 1.3,
    blocksMovement: true,
  },
  wood_beam_frame: {
    type: 'wood_beam_frame',
    label: 'Structure en bois',
    cost: [{ itemId: 'wood_log', quantity: 6 }],
    maxSlopeCos: 0.88,
    footprintRadius: 1.4,
    blocksMovement: true,
  },
  utility_shelter: {
    type: 'utility_shelter',
    label: 'Abri utilitaire',
    cost: [
      { itemId: 'wood_log', quantity: 10 },
      { itemId: 'stone_shard', quantity: 4 },
    ],
    maxSlopeCos: 0.9,
    footprintRadius: 1.8,
    blocksMovement: true,
  },
};
