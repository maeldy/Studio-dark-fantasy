import { CRAFTING_RECIPES } from '../data/craftingRecipes';
import { CraftingRecipe, StationType } from '../types/gameplay';
import { InventoryPort } from './EquipmentSystem';

export class CraftingSystem {
  private unlockedIds = new Set<string>(
    CRAFTING_RECIPES.filter((r) => r.unlockedByDefault).map((r) => r.id)
  );
  private busy = false;

  constructor(private inventory: InventoryPort) {}

  public setUnlockedRecipes(ids: string[]): void {
    this.unlockedIds = new Set(ids);
    for (const r of CRAFTING_RECIPES) {
      if (r.unlockedByDefault) this.unlockedIds.add(r.id);
    }
  }

  public getUnlockedRecipeIds(): string[] {
    return Array.from(this.unlockedIds);
  }

  public unlockRecipe(recipeId: string): boolean {
    const exists = CRAFTING_RECIPES.some((r) => r.id === recipeId);
    if (!exists) return false;
    this.unlockedIds.add(recipeId);
    return true;
  }

  public getRecipesForStation(station: StationType): CraftingRecipe[] {
    return CRAFTING_RECIPES.filter(
      (r) => r.station === station && this.unlockedIds.has(r.id)
    );
  }

  public canCraft(recipe: CraftingRecipe, currentStation: StationType): boolean {
    if (!this.unlockedIds.has(recipe.id)) return false;
    if (recipe.station !== 'none' && recipe.station !== currentStation) return false;
    return recipe.ingredients.every(
      (ing) => this.inventory.getCount(ing.itemId) >= ing.quantity
    );
  }

  public craft(
    recipeId: string,
    currentStation: StationType
  ): { ok: boolean; recipe?: CraftingRecipe; error?: string } {
    if (this.busy) return { ok: false, error: 'Fabrication déjà en cours.' };
    const recipe = CRAFTING_RECIPES.find((r) => r.id === recipeId);
    if (!recipe) return { ok: false, error: 'Recette introuvable.' };
    if (!this.canCraft(recipe, currentStation)) {
      return { ok: false, error: 'Ressources ou installation manquantes.' };
    }

    this.busy = true;
    try {
      for (const ing of recipe.ingredients) {
        if (this.inventory.getCount(ing.itemId) < ing.quantity) {
          return { ok: false, error: 'Quantité insuffisante.' };
        }
      }
      for (const ing of recipe.ingredients) {
        const removed = this.inventory.removeItem(ing.itemId, ing.quantity);
        if (!removed) return { ok: false, error: 'Erreur de retrait matériau.' };
      }
      this.inventory.addItem(recipe.resultItemId, recipe.resultQuantity);
      return { ok: true, recipe };
    } finally {
      this.busy = false;
    }
  }
}
