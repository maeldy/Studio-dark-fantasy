import { CraftingRecipe } from '../types/gameplay';

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  {
    id: 'recipe_crude_axe',
    resultItemId: 'crude_axe',
    resultQuantity: 1,
    station: 'none',
    ingredients: [
      { itemId: 'wood_log', quantity: 3 },
      { itemId: 'stone_shard', quantity: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_crude_pickaxe',
    resultItemId: 'crude_pickaxe',
    resultQuantity: 1,
    station: 'none',
    ingredients: [
      { itemId: 'wood_log', quantity: 3 },
      { itemId: 'stone_shard', quantity: 3 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_forager_knife',
    resultItemId: 'forager_knife',
    resultQuantity: 1,
    station: 'none',
    ingredients: [
      { itemId: 'wood_log', quantity: 1 },
      { itemId: 'stone_shard', quantity: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_iron_ingot',
    resultItemId: 'iron_ingot',
    resultQuantity: 1,
    station: 'furnace',
    ingredients: [
      { itemId: 'iron_ore', quantity: 2 },
      { itemId: 'wood_log', quantity: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_iron_axe',
    resultItemId: 'iron_axe',
    resultQuantity: 1,
    station: 'workbench',
    ingredients: [
      { itemId: 'iron_ingot', quantity: 2 },
      { itemId: 'wood_log', quantity: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_iron_pickaxe',
    resultItemId: 'iron_pickaxe',
    resultQuantity: 1,
    station: 'workbench',
    ingredients: [
      { itemId: 'iron_ingot', quantity: 2 },
      { itemId: 'wood_log', quantity: 2 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_thorn_short_sword',
    resultItemId: 'thorn_short_sword',
    resultQuantity: 1,
    station: 'forge',
    ingredients: [
      { itemId: 'iron_ingot', quantity: 2 },
      { itemId: 'leather_scrap', quantity: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_round_wooden_shield',
    resultItemId: 'round_wooden_shield',
    resultQuantity: 1,
    station: 'workbench',
    ingredients: [
      { itemId: 'wood_log', quantity: 4 },
      { itemId: 'iron_ingot', quantity: 1 },
    ],
    unlockedByDefault: true,
  },
  {
    id: 'recipe_iron_chainmail',
    resultItemId: 'iron_chainmail',
    resultQuantity: 1,
    station: 'anvil',
    ingredients: [
      { itemId: 'iron_ingot', quantity: 4 },
      { itemId: 'leather_scrap', quantity: 2 },
    ],
    unlockedByDefault: false,
    unlockHint: 'Découvrir une ancienne forge ou un sanctuaire de Thornvale.',
  },
];
