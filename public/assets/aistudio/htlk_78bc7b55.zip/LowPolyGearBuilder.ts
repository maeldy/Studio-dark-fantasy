import * as THREE from 'three';
import { BuildableType, WeaponSpec } from '../types/gameplay';

const MATERIAL_HEX: Record<string, number> = {
  wood: 0x5a3d28,
  stone: 0x5c6066,
  iron: 0x7c848e,
  steel: 0xa6b0bc,
  leather: 0x6b442a,
  cloth: 0x4c5246,
};

function makeMat(tone: string): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: MATERIAL_HEX[tone] ?? 0x6c6860,
    roughness: 0.88,
    metalness: tone === 'iron' || tone === 'steel' ? 0.55 : 0.08,
    flatShading: true,
  });
}

export function createLowPolyWeaponMesh(spec: WeaponSpec): THREE.Group {
  const group = new THREE.Group();
  const hiltMat = makeMat('leather');
  const bladeMat = makeMat(spec.materialTone);

  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.22, 0.05), hiltMat);
  grip.position.y = 0.08;
  group.add(grip);

  switch (spec.category) {
    case 'dagger': {
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.34, 4), bladeMat);
      blade.position.y = 0.34;
      group.add(blade);
      break;
    }
    case 'short_sword':
    case 'long_sword': {
      const len = spec.category === 'long_sword' ? 0.92 : 0.64;
      const guard = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.05, 0.07), bladeMat);
      guard.position.y = 0.2;
      group.add(guard);
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, len, 0.025), bladeMat);
      blade.position.y = 0.22 + len * 0.5;
      group.add(blade);
      break;
    }
    case 'axe': {
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 0.85, 6), makeMat('wood'));
      shaft.position.y = 0.35;
      group.add(shaft);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.22, 0.05), bladeMat);
      head.position.set(0.11, 0.65, 0);
      group.add(head);
      break;
    }
    case 'mace': {
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.032, 0.75, 6), makeMat('wood'));
      shaft.position.y = 0.3;
      group.add(shaft);
      const head = new THREE.Mesh(new THREE.DodecahedronGeometry(0.13, 0), bladeMat);
      head.position.y = 0.68;
      group.add(head);
      break;
    }
    case 'spear': {
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.028, 1.55, 6), makeMat('wood'));
      shaft.position.y = 0.55;
      group.add(shaft);
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.24, 4), bladeMat);
      tip.position.y = 1.42;
      group.add(tip);
      break;
    }
    case 'bow': {
      const arc = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.025, 5, 10, Math.PI), makeMat('wood'));
      arc.rotation.z = -Math.PI * 0.5;
      arc.position.y = 0.38;
      group.add(arc);
      break;
    }
  }
  return group;
}

export function createLowPolyShieldMesh(): THREE.Group {
  const g = new THREE.Group();
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.05, 8), makeMat('wood'));
  disc.rotation.x = Math.PI * 0.5;
  const boss = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 4), makeMat('iron'));
  boss.position.z = 0.03;
  g.add(disc, boss);
  return g;
}

export function createLowPolyBuildableMesh(type: BuildableType): THREE.Group {
  const g = new THREE.Group();
  const wood = makeMat('wood');
  const stone = makeMat('stone');

  switch (type) {
    case 'campfire': {
      for (let i = 0; i < 6; i++) {
        const ang = (i / 6) * Math.PI * 2;
        const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.22, 0), stone);
        r.position.set(Math.cos(ang) * 0.65, 0.14, Math.sin(ang) * 0.65);
        g.add(r);
      }
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.12, 1.0, 5), wood);
      log.rotation.z = Math.PI * 0.42;
      log.position.y = 0.22;
      g.add(log);
      break;
    }
    case 'storage_chest': {
      const box = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.7, 0.65), wood);
      box.position.y = 0.35;
      g.add(box);
      break;
    }
    case 'workbench': {
      const top = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.14, 0.8), wood);
      top.position.y = 0.85;
      g.add(top);
      for (const lx of [-0.62, 0.62]) {
        for (const lz of [-0.3, 0.3]) {
          const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.82, 0.12), wood);
          leg.position.set(lx, 0.41, lz);
          g.add(leg);
        }
      }
      break;
    }
    case 'palisade':
    case 'small_barrier': {
      const h = type === 'palisade' ? 1.85 : 0.95;
      for (let i = -2; i <= 2; i++) {
        const stake = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, h, 5), wood);
        stake.position.set(i * 0.32, h * 0.5, 0);
        g.add(stake);
      }
      break;
    }
    case 'wood_beam_frame':
    case 'utility_shelter': {
      const base = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.16, 2.2), wood);
      base.position.y = 0.08;
      g.add(base);
      const postH = type === 'utility_shelter' ? 2.1 : 1.5;
      for (const px of [-0.95, 0.95]) {
        for (const pz of [-0.95, 0.95]) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, postH, 0.16), wood);
          post.position.set(px, postH * 0.5, pz);
          g.add(post);
        }
      }
      if (type === 'utility_shelter') {
        const roof = new THREE.Mesh(new THREE.ConeGeometry(1.75, 1.1, 4), wood);
        roof.rotation.y = Math.PI * 0.25;
        roof.position.y = postH + 0.52;
        g.add(roof);
      }
      break;
    }
  }
  return g;
}
